Fields Table

Task
| Field Name | Data Type | Required | Description |

| id | Long | Yes | id |
| title | String | Yes | title |
| description | String | No | description |
| status | TaskStatus | Yes | Progressing |
| createDate | LocalDate | Yes | created date |
| dueDate | LocalDate | Yes | deadline |
| user | User | Yes | Task owner |
| project | Project | No | belonging project |

User
| Field Name | Data Type | Required | Description |

| id | Long | Yes | id |
| username | String | Yes | username |
| password | String | Yes | password |
| email | String | Yes | email |
| role | UserRole | Yes | role |
| tasks | List<Task> | No | User's tasks |

Project
| Field Name | Data Type | Required | Description |

| id | Long | Yes | id |
| name | String | Yes | name |
| description | String | No | description |
| createDate | LocalDate | Yes | created date |
| tasks | List<Task> | No | Project's task |
