use Ts_ELISP;
GO

CREATE SEQUENCE AccountSeq
    START WITH 1
    INCREMENT BY 1;
GO
select * from Accounts
select * from Roles
INSERT INTO Roles (name) VALUES ('USER');
INSERT INTO Roles (name) VALUES ('EMPLOYEE');
INSERT INTO Roles (name) VALUES ('ADMIN');
CREATE TABLE Accounts (
    id INT IDENTITY PRIMARY KEY,
    account_code VARCHAR(12) UNIQUE NOT NULL
        DEFAULT ('ACC' + RIGHT('000000' + CAST(NEXT VALUE FOR AccountSeq AS VARCHAR(6)), 6)),
    username NVARCHAR(50) NOT NULL,
    gmail NVARCHAR(100) NOT NULL UNIQUE,                                
    phone NVARCHAR(20),
    password_hash VARCHAR(255) NOT NULL
);
GO

CREATE TABLE Roles (
    id INT IDENTITY PRIMARY KEY,
    name VARCHAR(20) NOT NULL CHECK (name IN ('USER','WORKER','ADMIN'))
);
GO

CREATE TABLE AccountRoles (
    account_id INT NOT NULL,
    role_id INT NOT NULL,
    PRIMARY KEY (account_id, role_id),
    FOREIGN KEY (account_id) REFERENCES Accounts(id),
    FOREIGN KEY (role_id) REFERENCES Roles(id)
);
GO

CREATE TABLE Categories (
    id BIGINT IDENTITY PRIMARY KEY,
    name NVARCHAR(100) NOT NULL
);

CREATE TABLE Brands (
    id BIGINT IDENTITY PRIMARY KEY,
    name NVARCHAR(100) NOT NULL
);
GO

CREATE TABLE Products (
    id BIGINT IDENTITY PRIMARY KEY,
    name NVARCHAR(255) NOT NULL,
    product_code VARCHAR(50) UNIQUE NOT NULL,
    description NVARCHAR(MAX),
    category_id BIGINT NOT NULL,
    brand_id BIGINT NOT NULL,
    release_date DATE,
    status VARCHAR(20) NOT NULL CHECK (status IN ('COMING','AVAILABLE','OUT_OF_STOCK')),
    created_at DATETIME DEFAULT GETDATE(),
    FOREIGN KEY (category_id) REFERENCES Categories(id),
    FOREIGN KEY (brand_id) REFERENCES Brands(id)
);
GO

CREATE TABLE Colors (
    id BIGINT IDENTITY PRIMARY KEY,
    name NVARCHAR(50) NOT NULL,
    hex_code VARCHAR(7)
);

CREATE TABLE Sizes (
    id BIGINT IDENTITY PRIMARY KEY,
    name NVARCHAR(20) NOT NULL,
    category_type NVARCHAR(50)
);
GO

CREATE TABLE ProductVariants (
    id BIGINT IDENTITY PRIMARY KEY,
    product_id BIGINT NOT NULL,
    size_id BIGINT NOT NULL,
    color_id BIGINT NOT NULL,
    price DECIMAL(12,2) NOT NULL,
    stock INT NOT NULL CHECK (stock >= 0),
    FOREIGN KEY (product_id) REFERENCES Products(id),
    FOREIGN KEY (size_id) REFERENCES Sizes(id),
    FOREIGN KEY (color_id) REFERENCES Colors(id),
    UNIQUE (product_id, size_id, color_id)
);
GO

CREATE TABLE Carts (
    id BIGINT IDENTITY PRIMARY KEY,
    account_id INT UNIQUE NOT NULL,
    FOREIGN KEY (account_id) REFERENCES Accounts(id)
);

CREATE TABLE CartItems (
    id BIGINT IDENTITY PRIMARY KEY,
    cart_id BIGINT NOT NULL,
    variant_id BIGINT NOT NULL,
    quantity INT NOT NULL CHECK (quantity > 0),
    FOREIGN KEY (cart_id) REFERENCES Carts(id),
    FOREIGN KEY (variant_id) REFERENCES ProductVariants(id),
    UNIQUE (cart_id, variant_id)
);
GO

CREATE TABLE PaymentMethods (
    id BIGINT IDENTITY PRIMARY KEY,
    name NVARCHAR(50) NOT NULL
);
GO

CREATE TABLE Orders (
    id BIGINT IDENTITY PRIMARY KEY,
    account_id INT NOT NULL,
    status VARCHAR(30) NOT NULL
        CHECK (status IN ('NEW','SHIPPING','SUCCESS','FAILED','RETURN_REQUEST')),
    payment_method_id BIGINT NOT NULL,
    payment_status VARCHAR(20) NOT NULL
        CHECK (payment_status IN ('PENDING','PAID','FAILED','REFUNDED')),
    created_at DATETIME DEFAULT GETDATE(),
    FOREIGN KEY (account_id) REFERENCES Accounts(id),
    FOREIGN KEY (payment_method_id) REFERENCES PaymentMethods(id)
);
GO

CREATE TABLE OrderItems (
    id BIGINT IDENTITY PRIMARY KEY,
    order_id BIGINT NOT NULL,
    variant_id BIGINT NOT NULL,
    price DECIMAL(12,2) NOT NULL,
    quantity INT NOT NULL,
    FOREIGN KEY (order_id) REFERENCES Orders(id),
    FOREIGN KEY (variant_id) REFERENCES ProductVariants(id)
);
GO

CREATE TABLE ProductLikes (
    account_id INT,
    product_id BIGINT,
    PRIMARY KEY (account_id, product_id),
    FOREIGN KEY (account_id) REFERENCES Accounts(id),
    FOREIGN KEY (product_id) REFERENCES Products(id)
);

CREATE TABLE ProductCompares (
    account_id INT,
    product_id BIGINT,
    PRIMARY KEY (account_id, product_id),
    FOREIGN KEY (account_id) REFERENCES Accounts(id),
    FOREIGN KEY (product_id) REFERENCES Products(id)
);

CREATE TABLE ProductNotify (
    account_id INT,
    product_id BIGINT,
    PRIMARY KEY (account_id, product_id),
    FOREIGN KEY (account_id) REFERENCES Accounts(id),
    FOREIGN KEY (product_id) REFERENCES Products(id)
);
GO

CREATE TABLE ProductReviews (
    id BIGINT IDENTITY PRIMARY KEY,
    product_id BIGINT NOT NULL,
    account_id INT NOT NULL,
    rating INT CHECK (rating BETWEEN 1 AND 5),
    comment NVARCHAR(1000),
    created_at DATETIME DEFAULT GETDATE(),
    FOREIGN KEY (product_id) REFERENCES Products(id),
    FOREIGN KEY (account_id) REFERENCES Accounts(id),
    UNIQUE (product_id, account_id)
);
GO

CREATE TABLE Feedbacks (
    id BIGINT IDENTITY PRIMARY KEY,
    account_id INT,
    content NVARCHAR(1000) NOT NULL,
    admin_reply NVARCHAR(1000),
    created_at DATETIME DEFAULT GETDATE(),
    FOREIGN KEY (account_id) REFERENCES Accounts(id)
);
GO


-- Insert Categories
INSERT INTO Categories (name) VALUES 
('Running Shoes'),
('Basketball Shoes'),
('Training Shoes'),
('Football Cleats'),
('Tennis Shoes'),
('Athletic Apparel'),
('Accessories'),
('Sports Equipment');

-- Insert Brands
INSERT INTO Brands (name) VALUES 
('Nike'),
('Adidas'),
('Puma'),
('Under Armour'),
('New Balance'),
('Asics'),
('Reebok'),
('Converse');

-- Insert Colors
INSERT INTO Colors (name, hex_code) VALUES 
('Black', '#000000'),
('White', '#FFFFFF'),
('Red', '#FF0000'),
('Blue', '#0000FF'),
('Green', '#008000'),
('Yellow', '#FFFF00'),
('Gray', '#808080'),
('Orange', '#FFA500'),
('Purple', '#800080'),
('Pink', '#FFC0CB'),
('Brown', '#A52A2A'),
('Navy Blue', '#000080');

-- Insert Sizes
INSERT INTO Sizes (name, category_type) VALUES 
-- Shoe sizes
('US 7', 'Footwear'),
('US 8', 'Footwear'),
('US 9', 'Footwear'),
('US 10', 'Footwear'),
('US 11', 'Footwear'),
('US 12', 'Footwear'),
('US 13', 'Footwear'),
-- Clothing sizes
('S', 'Apparel'),
('M', 'Apparel'),
('L', 'Apparel'),
('XL', 'Apparel'),
('XXL', 'Apparel'),
-- Generic sizes
('One Size', 'Universal');

-- Insert Products (8 products with different categories and brands)
INSERT INTO Products (name, product_code, description, category_id, brand_id, release_date, status) VALUES 
('Nike Air Max 270', 'NIKE-AM270-001', 'Revolutionary cushioning with the largest Air unit yet for all-day comfort. Perfect for running and casual wear.', 1, 1, '2023-01-15', 'AVAILABLE'),
('Adidas Ultraboost 22', 'ADID-UB22-001', 'Responsive Boost cushioning with Primeknit upper for adaptive fit and comfort during long runs.', 1, 2, '2022-11-10', 'AVAILABLE'),
('Nike LeBron 20', 'NIKE-LB20-001', 'Premium basketball shoes with Zoom Air cushioning and lockdown fit for explosive movements on court.', 2, 1, '2022-09-20', 'AVAILABLE'),
('Under Armour Curry 10', 'UA-CURY-001', 'Lightweight basketball shoes with UA Flow technology for superior traction and court feel.', 2, 4, '2023-03-05', 'COMING'),
('Puma Training Shoes', 'PUMA-TRN-001', 'Versatile training shoes with Flex technology for multi-directional movements and stability.', 3, 3, '2023-02-28', 'AVAILABLE'),
('Adidas Predator Football', 'ADID-PRED-001', 'Advanced football cleats with Demonskin technology for enhanced ball control and precision.', 4, 2, '2022-12-15', 'AVAILABLE'),
('Nike Court Air Zoom', 'NIKE-TEN-001', 'Tennis shoes with Zoom Air cushioning and durable outsole for hard court performance.', 5, 1, '2023-01-30', 'OUT_OF_STOCK'),
('Asics Gel-Kayano 29', 'ASICS-GK29-001', 'Stability running shoes with Gel cushioning for overpronators seeking maximum support.', 1, 6, '2022-10-20', 'AVAILABLE');

-- Insert Product Variants for each product
-- Nike Air Max 270 variants
INSERT INTO ProductVariants (product_id, size_id, color_id, price, stock) VALUES 
(1, 3, 1, 149.99, 25),  -- US 9, Black
(1, 4, 2, 149.99, 30),  -- US 10, White
(1, 4, 3, 149.99, 15),  -- US 10, Red
(1, 5, 8, 149.99, 10);  -- US 11, Orange

-- Adidas Ultraboost 22 variants
INSERT INTO ProductVariants (product_id, size_id, color_id, price, stock) VALUES 
(2, 3, 4, 179.99, 20),  -- US 9, Blue
(2, 4, 2, 179.99, 35),  -- US 10, White
(2, 5, 6, 179.99, 12);  -- US 11, Yellow

-- Nike LeBron 20 variants
INSERT INTO ProductVariants (product_id, size_id, color_id, price, stock) VALUES 
(3, 4, 1, 199.99, 8),   -- US 10, Black
(3, 5, 1, 199.99, 5),   -- US 11, Black
(3, 5, 3, 199.99, 7),   -- US 11, Red
(3, 6, 9, 199.99, 3);   -- US 12, Purple

-- Under Armour Curry 10 variants (COMING SOON)
INSERT INTO ProductVariants (product_id, size_id, color_id, price, stock) VALUES 
(4, 4, 2, 159.99, 0),   -- US 10, White
(4, 5, 4, 159.99, 0);   -- US 11, Blue

-- Puma Training Shoes variants
INSERT INTO ProductVariants (product_id, size_id, color_id, price, stock) VALUES 
(5, 3, 1, 89.99, 40),   -- US 9, Black
(5, 4, 1, 89.99, 45),   -- US 10, Black
(5, 4, 2, 89.99, 30);   -- US 10, White

-- Adidas Predator Football variants
INSERT INTO ProductVariants (product_id, size_id, color_id, price, stock) VALUES 
(6, 4, 3, 129.99, 18),  -- US 10, Red
(6, 4, 4, 129.99, 22),  -- US 10, Blue
(6, 5, 3, 129.99, 15);  -- US 11, Red

-- Nike Court Air Zoom variants (OUT OF STOCK)
INSERT INTO ProductVariants (product_id, size_id, color_id, price, stock) VALUES 
(7, 4, 2, 119.99, 0),   -- US 10, White
(7, 4, 1, 119.99, 0);   -- US 10, Black

-- Asics Gel-Kayano 29 variants
INSERT INTO ProductVariants (product_id, size_id, color_id, price, stock) VALUES 
(8, 3, 4, 159.99, 25),  -- US 9, Blue
(8, 4, 7, 159.99, 32),  -- US 10, Gray
(8, 5, 7, 159.99, 28);  -- US 11, Gray

-- Insert Payment Methods
INSERT INTO PaymentMethods (name) VALUES 
('Credit Card'),
('Debit Card'),
('PayPal'),
('Cash on Delivery'),
('Bank Transfer');

-- Insert some sample accounts for testing (if needed)
-- Note: Use your registration system for real accounts
DECLARE @newAccountId INT;

-- Sample user account
INSERT INTO Accounts (username, gmail, phone, password_hash) 
VALUES ('TestUser', 'user@example.com', '1234567890', '$2a$10$//cK4VkF.6aIdBfawH.Qj.yBGaqRhKnh/NsY.L9KNlINKmMvnurQu');

SET @newAccountId = SCOPE_IDENTITY();

-- Assign USER role to the sample account
INSERT INTO AccountRoles (account_id, role_id) 
VALUES (@newAccountId, (SELECT id FROM Roles WHERE name = 'USER'));

-- Create cart for the user
INSERT INTO Carts (account_id) VALUES (@newAccountId);

-- Insert some sample cart items
INSERT INTO CartItems (cart_id, variant_id, quantity) VALUES 
(1, 1, 2),  -- 2x Nike Air Max 270 Black US 9
(1, 6, 1);  -- 1x Adidas Ultraboost 22 White US 10

-- Insert sample order for the user
DECLARE @newOrderId BIGINT;

INSERT INTO Orders (account_id, status, payment_method_id, payment_status) 
VALUES (@newAccountId, 'SUCCESS', 1, 'PAID');

SET @newOrderId = SCOPE_IDENTITY();

-- Insert order items
INSERT INTO OrderItems (order_id, variant_id, price, quantity) VALUES 
(@newOrderId, 2, 149.99, 1),  -- Nike Air Max 270 White US 10
(@newOrderId, 8, 179.99, 1);  -- Adidas Ultraboost 22 White US 10

-- Insert some product reviews
INSERT INTO ProductReviews (product_id, account_id, rating, comment) VALUES 
(1, @newAccountId, 5, 'Extremely comfortable! Perfect for daily runs.'),
(2, @newAccountId, 4, 'Great cushioning but runs a bit small.');

-- Insert product likes
INSERT INTO ProductLikes (account_id, product_id) VALUES 
(@newAccountId, 1),
(@newAccountId, 3),
(@newAccountId, 5);

-- Insert sample feedback
INSERT INTO Feedbacks (account_id, content) VALUES 
(@newAccountId, 'Great website! Easy to use and products are high quality.');

-- Verify data
SELECT 'Categories:', COUNT(*) FROM Categories;
SELECT 'Brands:', COUNT(*) FROM Brands;
SELECT 'Products:', COUNT(*) FROM Products;
SELECT 'ProductVariants:', COUNT(*) FROM ProductVariants;
SELECT 'Colors:', COUNT(*) FROM Colors;
SELECT 'Sizes:', COUNT(*) FROM Sizes;

-- Sample query to view product data with all details
SELECT 
    p.name AS ProductName,
    p.product_code,
    b.name AS Brand,
    c.name AS Category,
    cl.name AS Color,
    s.name AS Size,
    pv.price,
    pv.stock,
    p.status,
    p.release_date
FROM Products p
JOIN Brands b ON p.brand_id = b.id
JOIN Categories c ON p.category_id = c.id
JOIN ProductVariants pv ON p.id = pv.product_id
JOIN Colors cl ON pv.color_id = cl.id
JOIN Sizes s ON pv.size_id = s.id
ORDER BY p.id, cl.name, s.name;