Business Rule

User - Task relationship

- A User can be assigned multiple Tasks
- A User can have none or many tasks
- A task can't exist without a user

Project - Task relationship

- A project can have many tasks
- A task can belong to one or none project
- A project can exist without any task
- A task can exist without belong to a project

User – Project relationship

- A user can participate in multiple projects
- A project can include multiple users

General

- All required fields mustn't null
- Email must be Unique and follow a valid email format
- Task status must be one of (TODO, IN_PROGRESS, DONE)
- User Role must be one of (USER, ADMIN)
